import XCTest
@testable import DimfulLogic

final class LogicTests: XCTestCase {
    let vless = "vless://123e4567-e89b-12d3-a456-426614174000@vpn.example.com:443?security=tls&sni=example.com&type=ws&path=%2Fhello&host=cdn.example.com#Example"
    func json(_ server: VPNServer) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: Data(server.outboundJSON.utf8)) as? [String: Any])
    }
    func testVLESSWebSocket() throws {
        let server = try SubscriptionParser.parseURI(vless)
        XCTAssertEqual(server.kind, "vless")
        XCTAssertEqual(server.name, "Example")
        let object = try json(server)
        let transport = try XCTUnwrap(object["transport"] as? [String: Any])
        XCTAssertEqual(transport["path"] as? String, "/hello")
        XCTAssertEqual((transport["headers"] as? [String: String])?["Host"], "cdn.example.com")
        XCTAssertEqual((object["tls"] as? [String: Any])?["server_name"] as? String, "example.com")
    }
    func testRealityAndGRPC() throws {
        let server = try SubscriptionParser.parseURI("vless://123e4567-e89b-12d3-a456-426614174000@example.com:443?security=reality&pbk=BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB&sid=ab&fp=chrome&type=grpc&serviceName=test")
        let object = try json(server)
        XCTAssertEqual((object["transport"] as? [String: Any])?["service_name"] as? String, "test")
        let tls = try XCTUnwrap(object["tls"] as? [String: Any])
        XCTAssertNotNil(tls["reality"])
        XCTAssertEqual((tls["utls"] as? [String: Any])?["fingerprint"] as? String, "chrome")
    }
    func testTrojanPercentEncodedPasswordIPv6() throws {
        let server = try SubscriptionParser.parseURI("trojan://abc%40d%3Ae@[2001:db8::1]:8443?sni=example.com#Test")
        XCTAssertEqual(server.host, "2001:db8::1")
        XCTAssertEqual(server.port, 8443)
        XCTAssertEqual(try json(server)["password"] as? String, "abc@d:e")
    }
    func testHysteriaProtocols() throws {
        let first = try SubscriptionParser.parseURI("hysteria://example.com:443?auth=secret&upmbps=15&downmbps=80&obfs=xplus&obfsParam=hello")
        let one = try json(first)
        XCTAssertEqual(one["auth_str"] as? String, "secret")
        XCTAssertEqual(one["up_mbps"] as? Int, 15)
        XCTAssertEqual(one["obfs"] as? String, "hello")
        let second = try SubscriptionParser.parseURI("hy2://user:password@example.com:443?obfs=salamander&obfs-password=obfuscated")
        let two = try json(second)
        XCTAssertEqual(second.kind, "hysteria2")
        XCTAssertEqual(two["password"] as? String, "user:password")
        XCTAssertEqual((two["obfs"] as? [String: String])?["password"], "obfuscated")
    }
    func testBase64DedupAndStableIDs() throws {
        let text = vless + "\n" + vless + "\nunsupported://secret@example.com"
        let source = UUID()
        let parsed = try SubscriptionParser.parse(Data(text.utf8).base64EncodedString(), subscriptionID: source)
        XCTAssertEqual(parsed.servers.count, 1)
        XCTAssertEqual(parsed.warnings.count, 1)
        XCTAssertFalse(parsed.warnings[0].contains("secret"))
        let again = try SubscriptionParser.parseURI(vless, subscriptionID: source)
        XCTAssertEqual(again.id, parsed.servers[0].id)
        XCTAssertNotEqual(again.id, try SubscriptionParser.parseURI(vless).id)
    }
    func testInvalidAndUnsupportedLinksFail() {
        for value in [
            "vless://not-a-uuid@example.com:443",
            "trojan://@example.com:443",
            "hy2://password@example.com:0",
            "hysteria://example.com:443?protocol=faketcp",
            "vless://123e4567-e89b-12d3-a456-426614174000@example.com:443?type=xhttp",
            "hy2://password@example.com:443?mport=1000-2000"
        ] { XCTAssertThrowsError(try SubscriptionParser.parseURI(value), value) }
    }
    func testJSONImportsOnlyNodes() throws {
        let original = try json(SubscriptionParser.parseURI(vless))
        let root: [String: Any] = ["outbounds": [["type": "direct", "tag": "direct"], original], "route": ["final": "direct"]]
        let text = String(decoding: try JSONSerialization.data(withJSONObject: root), as: UTF8.self)
        let result = try SubscriptionParser.parse(text)
        XCTAssertEqual(result.servers.count, 1)
        XCTAssertEqual(result.servers[0].kind, "vless")
    }
    func testDomainBoundariesAndIDNA() throws {
        let routing = RoutingPreferences()
        for host in ["web.max.ru", "online.sberbank.ru", "vk.com", "m.vk.com", "avito.ru", "gosuslugi.ru", "sberbank.com", "xn--e1afmkfd.xn--p1ai"] {
            XCTAssertTrue(routing.isDirect(domain: host), host)
        }
        for host in ["evilvk.com", "vk.com.example.org", "ruexample.com", "youtube.com", "example.com"] {
            XCTAssertFalse(routing.isDirect(domain: host), host)
        }
        XCTAssertEqual(try RoutingPreferences.normalizeDomain("https://VK.COM/video"), "vk.com")
        XCTAssertThrowsError(try RoutingPreferences.normalizeDomain("*.com"))
        XCTAssertThrowsError(try RoutingPreferences.normalizeDomain("bad..com"))
    }
    func testRoutingZonesCanBeDisabled() {
        var routing = RoutingPreferences()
        routing.directRussianZones = false
        XCTAssertFalse(routing.isDirect(domain: "anything.ru"))
        XCTAssertTrue(routing.isDirect(domain: "web.max.ru"))
        routing.extraDomains = ["example.org"]
        XCTAssertTrue(routing.isDirect(domain: "sub.example.org"))
    }
    func testConfigurationDefaultsToVPNAndCoversIPv6() throws {
        let server = try SubscriptionParser.parseURI(vless)
        let text = try ConfigBuilder.make(server: server, routing: RoutingPreferences())
        let config = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any])
        let route = try XCTUnwrap(config["route"] as? [String: Any])
        XCTAssertEqual(route["final"] as? String, "proxy")
        let inbounds = try XCTUnwrap(config["inbounds"] as? [[String: Any]])
        XCTAssertTrue((inbounds[0]["address"] as? [String] ?? []).contains { $0.contains(":") })
        let rules = try XCTUnwrap(route["rules"] as? [[String: Any]])
        XCTAssertTrue(rules.contains { $0["action"] as? String == "hijack-dns" })
        let dns = try XCTUnwrap(config["dns"] as? [String: Any])
        XCTAssertEqual(dns["final"] as? String, "dns-vpn")
        XCTAssertEqual(dns["reverse_mapping"] as? Bool, true)
    }
    func testProbeNeverCreatesTunnel() throws {
        let text = try ConfigBuilder.make(server: SubscriptionParser.parseURI(vless), routing: RoutingPreferences(), probe: true)
        let config = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any])
        XCTAssertEqual((config["inbounds"] as? [Any])?.count, 0)
        XCTAssertNil((config["route"] as? [String: Any])?["auto_detect_interface"])
    }
}

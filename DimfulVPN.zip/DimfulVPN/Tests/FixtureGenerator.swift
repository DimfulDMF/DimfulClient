import Foundation

@main struct FixtureGenerator {
    static func main() throws {
        let output = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
        let uris = [
            "vless://123e4567-e89b-12d3-a456-426614174000@vpn.example.com:443?security=tls&sni=example.com#VLESS",
            "vless://123e4567-e89b-12d3-a456-426614174000@vpn.example.com:443?security=reality&pbk=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA&sid=abcd&fp=chrome&flow=xtls-rprx-vision#Reality",
            "vless://123e4567-e89b-12d3-a456-426614174000@vpn.example.com:443?security=tls&type=ws&path=%2Fws#WS",
            "vless://123e4567-e89b-12d3-a456-426614174000@vpn.example.com:443?security=tls&type=grpc&serviceName=grpc#GRPC",
            "trojan://example-password@vpn.example.com:443?sni=example.com#Trojan",
            "hy2://example-password@vpn.example.com:443?sni=example.com&obfs=salamander&obfs-password=test#HY2",
            "hysteria://vpn.example.com:443?auth=example-password&upmbps=20&downmbps=100#HY1"
        ]
        for (index, uri) in uris.enumerated() {
            let server = try SubscriptionParser.parseURI(uri)
            for probe in [false, true] {
                let config = try ConfigBuilder.make(server: server, routing: RoutingPreferences(), probe: probe)
                let name = "\(index)-\(probe ? "probe" : "tunnel").json"
                try config.write(to: output.appendingPathComponent(name), atomically: true, encoding: .utf8)
            }
        }
        print("Generated 14 fixtures from the actual Swift code.")
    }
}

import copy
import datetime as dt
import importlib.util
import pathlib
import unittest

root = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('sign', root / 'Scripts/sign.py')
sign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sign)

class SigningTests(unittest.TestCase):
    def setUp(self):
        self.profile = {
            'ExpirationDate': dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=20),
            'ApplicationIdentifierPrefix': ['PREFIX1234'], 'TeamIdentifier': ['TEAM123456'],
            'ProvisionedDevices': ['example-udid'],
            'Entitlements': {
                'application-identifier': 'PREFIX1234.app.dimful.vpn',
                'com.apple.developer.team-identifier': 'TEAM123456',
                sign.NETWORK: ['packet-tunnel-provider'], sign.GROUPS: ['group.app.dimful.vpn'],
                'keychain-access-groups': ['PREFIX1234.*'], 'get-task-allow': False,
            }
        }
    def validate(self, profile=None):
        return sign.validate_profile(profile or self.profile, 'app.dimful.vpn', 'group.app.dimful.vpn')
    def test_valid_profile_expands_keychain_group(self):
        team, ent = self.validate()
        self.assertEqual(team, 'TEAM123456')
        self.assertEqual(ent['keychain-access-groups'], ['PREFIX1234.app.dimful.vpn'])
    def test_missing_vpn_entitlement_rejected(self):
        self.profile['Entitlements'].pop(sign.NETWORK)
        with self.assertRaisesRegex(ValueError, 'Network Extension'): self.validate()
    def test_wrong_group_rejected(self):
        self.profile['Entitlements'][sign.GROUPS] = ['group.someone.else']
        with self.assertRaisesRegex(ValueError, 'App Group'): self.validate()
    def test_wrong_id_rejected(self):
        self.profile['Entitlements']['application-identifier'] = 'PREFIX1234.*'
        with self.assertRaisesRegex(ValueError, 'exact bundle ID'): self.validate()
    def test_expired_rejected(self):
        self.profile['ExpirationDate'] = dt.datetime(2020, 1, 1)
        with self.assertRaisesRegex(ValueError, 'expired'): self.validate()
    def test_app_store_profile_rejected(self):
        self.profile.pop('ProvisionedDevices')
        with self.assertRaisesRegex(ValueError, 'Ad Hoc'): self.validate()
    def test_profile_not_mutated(self):
        original = copy.deepcopy(self.profile)
        self.validate()
        self.assertEqual(original, self.profile)

if __name__ == '__main__': unittest.main()

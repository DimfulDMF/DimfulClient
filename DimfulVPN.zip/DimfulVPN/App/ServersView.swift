// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI

struct ServersView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var vpn: VPNController
    var add: () -> Void
    @State private var search = ""
    @State private var probeTask: Task<Void, Never>?
    @State private var testingAll = false

    private var servers: [VPNServer] {
        model.state.servers.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.kind.localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        Screen(title: "Серверы", caption: "Выбирай маршрут") {
            HStack {
                Text("\(model.state.servers.count) серверов").font(.subheadline).foregroundStyle(Theme.muted)
                Spacer()
                Button(action: add) { Image(systemName: "plus.circle.fill").font(.title2) }
            }
            TextField("Поиск сервера", text: $search).padding(14).background(Theme.panel, in: RoundedRectangle(cornerRadius: 16))
            HStack {
                Button(testingAll ? "Остановить проверку" : "Проверить все") {
                    if testingAll { probeTask?.cancel() }
                    else {
                        testingAll = true
                        probeTask = Task { await model.probeAll(); testingAll = false }
                    }
                }.buttonStyle(.bordered).disabled(vpn.active || (model.state.servers.isEmpty))
                Spacer()
                if !model.probing.isEmpty { ProgressView().tint(Theme.violet) }
            }
            Text(vpn.active ? "Для сравнения задержки отключи VPN. Выбор другого сервера применится при следующем подключении." : "Задержка HTTPS через сервер, включая авторизацию. До 5 секунд на сервер; это не ICMP ping.")
                .font(.footnote).foregroundStyle(Theme.muted)
            if servers.isEmpty {
                ContentUnavailableView("Пока пусто", systemImage: "server.rack", description: Text("Добавь подписку или вставь ссылку сервера."))
            }
            LazyVStack(spacing: 12) {
                ForEach(servers) { server in
                    Card {
                        VStack(alignment: .leading, spacing: 12) {
                            Button { model.select(server) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: model.state.selectedID == server.id ? "checkmark.circle.fill" : "circle")
                                        .font(.title2).foregroundStyle(model.state.selectedID == server.id ? Theme.violet : Theme.muted)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(server.name).font(.system(size: 16, weight: .semibold)).foregroundStyle(.white).lineLimit(2)
                                        Text("\(server.host):\(server.port)").font(.system(size: 11, design: .monospaced)).foregroundStyle(Theme.muted).lineLimit(1)
                                    }
                                    Spacer(minLength: 0)
                                }.contentShape(Rectangle())
                            }.buttonStyle(.plain)
                            HStack {
                                CapsuleLabel(title: server.label)
                                if server.skipsTLSVerification { CapsuleLabel(title: "TLS БЕЗ ПРОВЕРКИ", color: .orange) }
                                Spacer()
                                Button {
                                    Task { await model.probe(server) }
                                } label: {
                                    if model.probing.contains(server.id) { ProgressView().scaleEffect(0.75) }
                                    else { Text(model.latency[server.id].map { "\($0) мс" } ?? (model.probeFailures.contains(server.id) ? "Нет ответа" : "Пинг ↗")) }
                                }.font(.system(size: 12, weight: .semibold, design: .monospaced))
                                    .disabled(vpn.active || !model.probing.isEmpty)
                            }
                        }
                    }.contextMenu {
                        Button("Удалить сервер", role: .destructive) { model.removeServer(server.id) }.disabled(model.working)
                    }
                }
            }
        }.onDisappear { probeTask?.cancel() }
    }
}

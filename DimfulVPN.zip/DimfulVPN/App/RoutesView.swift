// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI

struct RoutesView: View {
    @EnvironmentObject private var model: AppModel
    @State private var domain = ""
    @State private var check = ""
    var body: some View {
        Screen(title: "Маршруты", caption: "Один VPN. Два направления.") {
            Card {
                VStack(alignment: .leading, spacing: 15) {
                    Label("Напрямую · твой IP", systemImage: "arrow.up.right").foregroundStyle(Theme.mint).font(.headline)
                    Text("MAX · VK · Avito · Госуслуги\nБанки и дополнительные домены").font(.subheadline)
                    Divider().overlay(.white.opacity(0.04))
                    Toggle("Все .ru, .рф и .su", isOn: Binding(get: { model.state.routing.directRussianZones }, set: {
                        var routing = model.state.routing; routing.directRussianZones = $0; model.setRouting(routing)
                    })).tint(Theme.violet)
                    Toggle("Локальная сеть", isOn: Binding(get: { model.state.routing.directPrivateNetworks }, set: {
                        var routing = model.state.routing; routing.directPrivateNetworks = $0; model.setRouting(routing)
                    })).tint(Theme.violet)
                }
            }
            Card {
                HStack {
                    VStack(alignment: .leading, spacing: 7) {
                        Label("Остальные сайты", systemImage: "globe").font(.headline)
                        Text("Через выбранный VPN-сервер").font(.footnote).foregroundStyle(Theme.muted)
                    }
                    Spacer()
                    CapsuleLabel(title: "VPN IP")
                }
            }
            VStack(alignment: .leading, spacing: 12) {
                Text("Добавить прямой домен").font(.headline)
                HStack {
                    TextField("example.com", text: $domain).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    Button(action: addDomain) { Image(systemName: "plus.circle.fill").font(.title2) }.disabled(domain.isEmpty)
                }.padding(15).background(Theme.panel, in: RoundedRectangle(cornerRadius: 16))
                ForEach(model.state.routing.extraDomains, id: \.self) { host in
                    HStack {
                        Text(host).font(.system(.subheadline, design: .monospaced))
                        Spacer()
                        Button(role: .destructive) {
                            var routing = model.state.routing; routing.extraDomains.removeAll { $0 == host }; model.setRouting(routing)
                        } label: { Image(systemName: "minus.circle") }
                    }.padding(.vertical, 5)
                }
            }
            Card {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Проверить правило").font(.headline)
                    TextField("Домен или адрес сайта", text: $check).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    if !check.isEmpty {
                        Label(model.state.routing.isDirect(domain: check) ? "Напрямую · текущий IP" : "Через VPN · IP сервера", systemImage: "arrow.triangle.branch")
                            .font(.subheadline).foregroundStyle(model.state.routing.isDirect(domain: check) ? Theme.mint : Theme.violet)
                    }
                    Text("Это проверка списка доменов, а не сетевой тест.").font(.caption).foregroundStyle(Theme.muted)
                }
            }
            DisclosureGroup("Встроенные домены: \(RoutingPreferences.serviceDomains.count)") {
                Text(RoutingPreferences.serviceDomains.joined(separator: "\n")).font(.system(size: 12, design: .monospaced)).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 10).textSelection(.enabled)
            }.font(.subheadline)
            Text("Изменения применяются после переподключения. Если ты за границей, прямой IP тоже будет зарубежным. Список банков не исчерпывающий: дополнительные домены можно добавить выше.")
                .font(.footnote).foregroundStyle(Theme.muted)
        }
    }
    private func addDomain() {
        do {
            let host = try RoutingPreferences.normalizeDomain(domain)
            var routing = model.state.routing
            routing.extraDomains = Array(Set(routing.extraDomains + [host])).sorted()
            model.setRouting(routing)
            domain = ""
        } catch { model.notice = error.localizedDescription }
    }
}

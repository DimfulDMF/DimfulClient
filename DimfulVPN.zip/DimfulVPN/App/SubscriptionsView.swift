// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI

struct SubscriptionsView: View {
    @EnvironmentObject private var model: AppModel
    var add: () -> Void
    @State private var deleting: Subscription?
    var body: some View {
        Screen(title: "Подписки", caption: "Твои провайдеры") {
            Button(action: add) { Label("Добавить подписку", systemImage: "plus").frame(maxWidth: .infinity).padding(8) }.buttonStyle(.borderedProminent)
            if model.state.subscriptions.isEmpty {
                ContentUnavailableView("Нет подписок", systemImage: "link", description: Text("Вставь HTTPS-ссылку своего VPN-провайдера."))
            }
            ForEach(model.state.subscriptions) { item in
                Card {
                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            Image(systemName: "square.stack.3d.up.fill").foregroundStyle(Theme.violet)
                            Text(item.name).font(.headline)
                            Spacer()
                            Text("\(item.importedCount)").font(.system(.headline, design: .monospaced)).foregroundStyle(Theme.muted)
                        }
                        Text(URL(string: item.url)?.host ?? "Подписка").font(.footnote).foregroundStyle(Theme.muted)
                        if let date = item.updatedAt { Text("Обновлено: " + date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(Theme.muted) }
                        HStack {
                            Button { Task { await model.refresh(item) } } label: { Label("Обновить", systemImage: "arrow.clockwise") }.disabled(model.working)
                            Spacer()
                            Button(role: .destructive) { deleting = item } label: { Image(systemName: "trash") }.disabled(model.working)
                        }.font(.subheadline)
                    }
                }
            }
            Text("При ошибке обновления старые серверы сохраняются. Обновление ручное. Для смены активного профиля переподключи VPN.")
                .font(.footnote).foregroundStyle(Theme.muted)
        }
        .confirmationDialog("Удалить подписку и её серверы?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { if let id = deleting?.id { model.removeSubscription(id) }; deleting = nil }
        }
    }
}

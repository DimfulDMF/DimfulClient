// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI

@main @MainActor struct DimfulVPNApp: App {
    @StateObject private var model = AppModel()
    @StateObject private var vpn = VPNController()
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(model).environmentObject(vpn)
                .preferredColorScheme(.dark).tint(Theme.violet)
        }
    }
}

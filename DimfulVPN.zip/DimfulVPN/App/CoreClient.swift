// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation
import Libbox

enum CoreClient {
    static func validate(_ config: String) throws {
        var error: NSError?
        LibboxCheckConfig(config, &error)
        if let error { throw error }
    }
    static func latency(_ config: String) async throws -> Int {
        try await Task.detached(priority: .userInitiated) {
            var error: NSError?
            let value = LibboxDimfulProbe(config, "https://www.gstatic.com/generate_204", 5000, &error)
            if let error { throw error }
            guard let value, let ms = Int(value.value) else { throw VPNFailure("Сервер не ответил на проверку.") }
            return ms
        }.value
    }
}

// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation
import Security

enum SecureStore {
    private static var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: (Bundle.main.bundleIdentifier ?? "app.dimful.vpn") + ".profiles",
         kSecAttrAccount as String: "state-v1"]
    }
    static func load() throws -> SavedState {
        var q = query
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &result)
        if status == errSecItemNotFound { return SavedState() }
        guard status == errSecSuccess, let data = result as? Data else {
            throw VPNFailure("Не удалось прочитать профили из Keychain: \(status). Разблокируйте iPhone.")
        }
        return try JSONDecoder().decode(SavedState.self, from: data)
    }
    static func save(_ state: SavedState) throws {
        let data = try JSONEncoder().encode(state)
        let attributes: [String: Any] = [kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        var status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            status = SecItemAdd(query.merging(attributes) { _, new in new } as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw VPNFailure("Не удалось сохранить профили: Keychain \(status).") }
    }
}

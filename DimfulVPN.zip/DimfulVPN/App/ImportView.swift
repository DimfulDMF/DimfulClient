// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI

struct ImportView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var text = ""
    @State private var error: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Image(systemName: "link.circle.fill").font(.system(size: 58)).foregroundStyle(Theme.violet).padding(.top, 12)
                    Text("Все серверы.\nВ одном месте.").font(.system(size: 29, weight: .bold, design: .rounded))
                    TextField("Название подписки (необязательно)", text: $title).textFieldStyle(.roundedBorder)
                    TextEditor(text: $text).font(.system(size: 12, design: .monospaced)).frame(minHeight: 165)
                        .scrollContentBackground(.hidden).padding(10).background(Theme.panel, in: RoundedRectangle(cornerRadius: 16))
                        .autocorrectionDisabled().textInputAutocapitalization(.never)
                        .overlay(alignment: .topLeading) {
                            if text.isEmpty { Text("https://… подписка\nили vless://, trojan://, hy2://, hysteria://").font(.system(size: 12)).foregroundStyle(Theme.muted).padding(18).allowsHitTesting(false) }
                        }
                    PasteButton(payloadType: String.self) { strings in text = strings.joined(separator: "\n") }
                    Text("Поддерживаются список ссылок, Base64 и JSON sing-box. Пароли и адрес подписки сохраняются в Keychain этого iPhone.")
                        .font(.footnote).foregroundStyle(Theme.muted)
                    if let error { Text(error).font(.footnote).foregroundStyle(.orange) }
                    Button {
                        Task {
                            do { try await model.importText(text, title: title); dismiss() }
                            catch { self.error = error.localizedDescription }
                        }
                    } label: {
                        HStack {
                            if model.working { ProgressView().tint(.white) }
                            Text(model.working ? "Импортируем…" : "Добавить")
                        }.frame(maxWidth: .infinity).padding(10)
                    }.buttonStyle(.borderedProminent).disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.working)
                }.padding(24)
            }.background(Theme.background)
                .navigationTitle("Добавить").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() }.disabled(model.working) } }
        }.interactiveDismissDisabled(model.working)
    }
}

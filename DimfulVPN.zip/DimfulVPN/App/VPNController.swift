// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation
import NetworkExtension
import Combine

@MainActor final class VPNController: ObservableObject {
    @Published private(set) var status: NEVPNStatus = .disconnected
    @Published private(set) var busy = false
    @Published private(set) var activeName: String?
    private var manager: NETunnelProviderManager?
    private var observer: NSObjectProtocol?

    init() {
        observer = NotificationCenter.default.addObserver(forName: .NEVPNStatusDidChange, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in self?.updateStatus() }
        }
    }
    deinit { if let observer { NotificationCenter.default.removeObserver(observer) } }

    var connected: Bool { status == .connected }
    var active: Bool { [.connecting, .connected, .reasserting, .disconnecting].contains(status) }
    var statusText: String {
        switch status {
        case .connected: return "Подключено"
        case .connecting: return "Подключение…"
        case .reasserting: return "Восстанавливаем сеть…"
        case .disconnecting: return "Отключение…"
        default: return "Готов к подключению"
        }
    }
    private var extensionID: String { (Bundle.main.bundleIdentifier ?? "app.dimful.vpn") + ".PacketTunnel" }

    func load() async throws {
        let managers = try await NETunnelProviderManager.loadAllFromPreferences()
        manager = managers.first { ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == extensionID }
        updateStatus()
    }
    private func updateStatus() {
        status = manager?.connection.status ?? .disconnected
        activeName = (manager?.protocolConfiguration as? NETunnelProviderProtocol)?.providerConfiguration?["serverName"] as? String
    }
    func connect(server: VPNServer, config: String) async throws {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        if manager == nil { try await load() }
        if active { try await stopAndWait() }
        try SharedPaths.writeConfig(config)
        let manager = self.manager ?? NETunnelProviderManager()
        let proto = NETunnelProviderProtocol()
        proto.providerBundleIdentifier = extensionID
        proto.serverAddress = server.host
        proto.providerConfiguration = ["serverName": server.name]
        proto.disconnectOnSleep = false
        proto.includeAllNetworks = false
        manager.protocolConfiguration = proto
        manager.localizedDescription = "Dimful VPN"
        manager.isEnabled = true
        manager.isOnDemandEnabled = false
        try await manager.saveToPreferences()
        try await manager.loadFromPreferences()
        self.manager = manager
        try manager.connection.startVPNTunnel()
        updateStatus()
    }
    func disconnect() async throws {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        try await stopAndWait()
    }
    private func stopAndWait() async throws {
        manager?.connection.stopVPNTunnel()
        for _ in 0..<150 {
            updateStatus()
            if !active { return }
            try await Task.sleep(nanoseconds: 100_000_000)
        }
        throw VPNFailure("iOS ещё отключает VPN. Подождите и повторите.")
    }
}

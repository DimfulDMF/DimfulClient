// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI

enum Theme {
    static let background = Color(red: 0.035, green: 0.04, blue: 0.075)
    static let panel = Color(red: 0.075, green: 0.085, blue: 0.14)
    static let violet = Color(red: 0.65, green: 0.49, blue: 1)
    static let mint = Color(red: 0.42, green: 0.94, blue: 0.77)
    static let muted = Color(red: 0.58, green: 0.61, blue: 0.72)
    static let gradient = LinearGradient(colors: [violet, Color(red: 0.39, green: 0.34, blue: 0.94)], startPoint: .topLeading, endPoint: .bottomTrailing)
}

struct Card<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        content.padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.panel.opacity(0.9), in: RoundedRectangle(cornerRadius: 23))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(.white.opacity(0.06), lineWidth: 1))
    }
}

struct Screen<Content: View>: View {
    let title: String
    let caption: String
    @ViewBuilder let content: Content
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 7) {
                    Text(caption.uppercased()).font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(3).foregroundStyle(Theme.violet)
                    Text(title).font(.system(size: 33, weight: .bold, design: .rounded))
                }.padding(.top, 22)
                content
            }.padding(.horizontal, 22).padding(.bottom, 32)
        }.background(Theme.background)
    }
}

struct CapsuleLabel: View {
    var title: String
    var color: Color = Theme.violet
    var body: some View {
        Text(title).font(.system(size: 10, weight: .bold, design: .monospaced))
            .padding(.horizontal, 9).padding(.vertical, 5)
            .foregroundStyle(color).background(color.opacity(0.12), in: Capsule())
    }
}

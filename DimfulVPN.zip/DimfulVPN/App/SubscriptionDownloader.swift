// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation

private final class HTTPSOnlyRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url?.scheme?.lowercased() == "https" ? request : nil)
    }
}

enum SubscriptionDownloader {
    static func fetch(_ address: String) async throws -> String {
        guard let url = URL(string: address.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme?.lowercased() == "https", url.host != nil, url.user == nil, url.password == nil else {
            throw VPNFailure("Подписка должна быть HTTPS-ссылкой. Токен в пути или параметрах поддерживается.")
        }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 20
        config.timeoutIntervalForResource = 30
        config.httpCookieStorage = nil
        config.urlCache = nil
        let session = URLSession(configuration: config, delegate: HTTPSOnlyRedirects(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: url)
        request.setValue("DimfulVPN/1.0 sing-box", forHTTPHeaderField: "User-Agent")
        request.setValue("application/json, text/plain, */*", forHTTPHeaderField: "Accept")
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw VPNFailure("Подписка вернула HTTP \((response as? HTTPURLResponse)?.statusCode ?? 0).")
        }
        guard response.expectedContentLength <= Int64(SubscriptionParser.maxBytes) else { throw VPNFailure("Подписка больше 4 МБ.") }
        var data = Data()
        for try await byte in bytes {
            guard data.count < SubscriptionParser.maxBytes else { throw VPNFailure("Подписка больше 4 МБ.") }
            data.append(byte)
        }
        guard let text = String(data: data, encoding: .utf8) else { throw VPNFailure("Подписка должна быть текстом UTF-8.") }
        return text
    }
}

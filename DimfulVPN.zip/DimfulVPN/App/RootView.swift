// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI
import NetworkExtension

struct RootView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var vpn: VPNController
    @State private var tab = 0
    @State private var adding = false

    var body: some View {
        TabView(selection: $tab) {
            HomeView(add: { adding = true }, showServers: { tab = 1 })
                .tabItem { Label("Главная", systemImage: "circle.hexagongrid.fill") }.tag(0)
            ServersView(add: { adding = true })
                .tabItem { Label("Серверы", systemImage: "server.rack") }.tag(1)
            RoutesView().tabItem { Label("Маршруты", systemImage: "arrow.triangle.branch") }.tag(2)
            SubscriptionsView(add: { adding = true })
                .tabItem { Label("Подписки", systemImage: "square.stack.3d.up") }.tag(3)
        }
        .toolbarBackground(Theme.background, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .sheet(isPresented: $adding) { ImportView() }
        .alert("Dimful VPN", isPresented: Binding(get: { model.notice != nil }, set: { if !$0 { model.notice = nil } })) {
            Button("Понятно", role: .cancel) { model.notice = nil }
        } message: { Text(model.notice ?? "") }
        .task {
            do { try await vpn.load() } catch { model.notice = error.localizedDescription }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var vpn: VPNController
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var add: () -> Void
    var showServers: () -> Void
    @State private var breathe = false

    var body: some View {
        Screen(title: "Dimful VPN", caption: "Твой интернет. Твои правила.") {
            HStack {
                CapsuleLabel(title: vpn.connected ? "VPN АКТИВЕН" : "SMART ROUTING", color: vpn.connected ? Theme.mint : Theme.violet)
                Spacer()
                Text("01 / CONNECT").font(.system(size: 10, design: .monospaced)).foregroundStyle(Theme.muted)
            }
            VStack(spacing: 17) {
                ZStack {
                    Circle().fill(Theme.violet.opacity(0.12)).frame(width: 244, height: 244).blur(radius: 20)
                    Circle().stroke(Theme.violet.opacity(0.10), lineWidth: 1).frame(width: 242, height: 242)
                    Circle().stroke(Theme.violet.opacity(breathe && vpn.connected ? 0.6 : 0.15), lineWidth: 1)
                        .frame(width: 209, height: 209).scaleEffect(breathe && vpn.connected ? 1.06 : 1)
                    Button(action: toggle) {
                        ZStack {
                            Circle().fill(Theme.gradient)
                            Circle().stroke(.white.opacity(0.25), lineWidth: 1).padding(1)
                            if vpn.busy || [.connecting, .disconnecting, .reasserting].contains(vpn.status) {
                                ProgressView().tint(.white).scaleEffect(1.8)
                            } else {
                                Image(systemName: "power").font(.system(size: 55, weight: .light)).foregroundStyle(.white)
                            }
                        }.frame(width: 167, height: 167)
                            .shadow(color: Theme.violet.opacity(vpn.connected ? 0.5 : 0.22), radius: 30, y: 12)
                    }.buttonStyle(.plain).disabled(vpn.busy || model.working || !model.probing.isEmpty)
                        .accessibilityLabel(vpn.active ? "Отключить VPN" : "Подключить VPN")
                }.frame(maxWidth: .infinity).frame(height: 251)
                Text(vpn.statusText).font(.system(size: 23, weight: .semibold, design: .rounded))
                Text(vpn.connected ? "Остальные сайты используют IP сервера" : "Нажми, чтобы подключиться")
                    .font(.system(size: 13)).foregroundStyle(Theme.muted)
            }.frame(maxWidth: .infinity)
                .onAppear {
                    if !reduceMotion { withAnimation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true)) { breathe = true } }
                }
            Button(action: showServers) {
                Card {
                    HStack(spacing: 13) {
                        Image(systemName: "globe.europe.africa.fill").font(.system(size: 28)).foregroundStyle(Theme.violet)
                        VStack(alignment: .leading, spacing: 6) {
                            Text(vpn.active ? (vpn.activeName ?? "Сервер") : (model.selected?.name ?? "Добавь первый сервер"))
                                .font(.system(size: 16, weight: .semibold)).lineLimit(1)
                            Text(vpn.active ? "Текущее подключение" : (model.selected.map { "\($0.label) · \($0.host)" } ?? "Ссылка или подписка провайдера"))
                                .font(.system(size: 11)).foregroundStyle(Theme.muted).lineLimit(1)
                        }
                        Spacer(minLength: 2)
                        Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.muted)
                    }
                }
            }.buttonStyle(.plain)
            HStack(spacing: 12) {
                Card {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("ЗАДЕРЖКА", systemImage: "waveform.path.ecg").font(.system(size: 9, weight: .bold)).foregroundStyle(Theme.muted)
                        Text(model.selected.flatMap { model.latency[$0.id] }.map { "\($0) мс" } ?? "— мс")
                            .font(.system(size: 23, weight: .semibold, design: .rounded))
                        Button("Проверить") { if let node = model.selected { Task { await model.probe(node) } } }
                            .font(.system(size: 12, weight: .semibold))
                            .disabled(model.selected == nil || !model.probing.isEmpty || vpn.active)
                    }
                }
                Card {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("РЕЖИМ", systemImage: "arrow.triangle.branch").font(.system(size: 9, weight: .bold)).foregroundStyle(Theme.muted)
                        Text("Умный").font(.system(size: 23, weight: .semibold, design: .rounded))
                        Text("RU → напрямую").font(.system(size: 12, weight: .medium)).foregroundStyle(Theme.mint)
                    }
                }
            }
            Card {
                HStack(alignment: .top, spacing: 12) {
                    Image(systemName: "arrow.turn.up.right").foregroundStyle(Theme.mint)
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Банки и сервисы РФ — напрямую").font(.system(size: 13, weight: .semibold))
                        Text("MAX, VK, Avito и Госуслуги увидят IP твоего текущего подключения.")
                            .font(.system(size: 12)).foregroundStyle(Theme.muted)
                    }
                }
            }
            if let node = model.selected, model.probeFailures.contains(node.id) {
                Text("Проверка не прошла: сервер или тестовый сайт недоступен. Проверь подписку и сеть.").font(.footnote).foregroundStyle(.orange)
            }
            if model.state.servers.isEmpty {
                Button(action: add) { Label("Добавить подписку", systemImage: "plus").frame(maxWidth: .infinity).padding(7) }.buttonStyle(.borderedProminent)
            }
        }
    }
    private func toggle() {
        if model.selected == nil && !vpn.active { add(); return }
        Task {
            do {
                if vpn.active { try await vpn.disconnect() }
                else if let server = model.selected {
                    let config = try ConfigBuilder.make(server: server, routing: model.state.routing)
                    try CoreClient.validate(config)
                    try await vpn.connect(server: server, config: config)
                }
            } catch { model.notice = error.localizedDescription }
        }
    }
}

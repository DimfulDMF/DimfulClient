// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation
import Combine

@MainActor final class AppModel: ObservableObject {
    @Published private(set) var state = SavedState()
    @Published var notice: String?
    @Published var working = false
    @Published private(set) var latency: [String: Int] = [:]
    @Published private(set) var probeFailures: Set<String> = []
    @Published private(set) var probing: Set<String> = []
    private var canSave = true

    init() {
        do { state = try SecureStore.load() }
        catch { canSave = false; notice = error.localizedDescription }
    }
    var selected: VPNServer? { state.servers.first { $0.id == state.selectedID } }
    private func commit(_ next: SavedState) throws {
        guard canSave else { throw VPNFailure("Профили не были прочитаны. Перезапустите приложение после разблокировки iPhone.") }
        try SecureStore.save(next)
        state = next
    }
    func select(_ server: VPNServer) {
        var next = state
        next.selectedID = server.id
        do { try commit(next) } catch { notice = error.localizedDescription }
    }
    func importText(_ text: String, title: String) async throws {
        guard !working else { throw VPNFailure("Дождитесь текущего импорта.") }
        working = true
        defer { working = false }
        let isURL = text.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().hasPrefix("https://")
        var subscription: Subscription?
        var body = text
        if isURL {
            let address = text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !state.subscriptions.contains(where: { $0.url == address }) else { throw VPNFailure("Эта подписка уже добавлена. Нажмите «Обновить».") }
            subscription = Subscription(name: title.isEmpty ? "Подписка \(state.subscriptions.count + 1)" : title, url: address)
            body = try await SubscriptionDownloader.fetch(address)
        }
        let result = try SubscriptionParser.parse(body, subscriptionID: subscription?.id)
        let accepted = try await validate(result.servers)
        var next = state
        var ids = Set(next.servers.map(\.id))
        next.servers += accepted.filter { ids.insert($0.id).inserted }
        if var subscription {
            subscription.updatedAt = Date()
            subscription.importedCount = accepted.count
            next.subscriptions.append(subscription)
        }
        if next.selectedID == nil { next.selectedID = accepted.first?.id }
        try commit(next)
        if !result.warnings.isEmpty { notice = "Импортировано: \(accepted.count). Пропущено: \(result.warnings.count).\n" + result.warnings.prefix(3).joined(separator: "\n") }
    }
    private func validate(_ servers: [VPNServer]) async throws -> [VPNServer] {
        // Validate every outbound before committing. Failure leaves old state intact.
        let routing = state.routing
        return try await Task.detached(priority: .userInitiated) {
            for server in servers {
                do { try CoreClient.validate(ConfigBuilder.make(server: server, routing: routing, probe: true)) }
                catch { throw VPNFailure("Некорректный профиль «\(server.name)»: \(error.localizedDescription)") }
            }
            return servers
        }.value
    }
    func refresh(_ subscription: Subscription) async {
        guard !working else { return }
        working = true
        defer { working = false }
        do {
            let body = try await SubscriptionDownloader.fetch(subscription.url)
            let result = try SubscriptionParser.parse(body, subscriptionID: subscription.id)
            let accepted = try await validate(result.servers)
            var next = state
            next.servers.removeAll { $0.subscriptionID == subscription.id }
            next.servers += accepted
            if let index = next.subscriptions.firstIndex(where: { $0.id == subscription.id }) {
                next.subscriptions[index].updatedAt = Date()
                next.subscriptions[index].importedCount = accepted.count
            }
            if !next.servers.contains(where: { $0.id == next.selectedID }) { next.selectedID = accepted.first?.id }
            try commit(next)
            if !result.warnings.isEmpty { notice = "Обновлено: \(accepted.count). Пропущено: \(result.warnings.count).\n" + result.warnings.prefix(3).joined(separator: "\n") }
        } catch { notice = "Старые серверы сохранены. " + error.localizedDescription }
    }
    func removeSubscription(_ id: UUID) {
        var next = state
        next.subscriptions.removeAll { $0.id == id }
        next.servers.removeAll { $0.subscriptionID == id }
        if !next.servers.contains(where: { $0.id == next.selectedID }) { next.selectedID = next.servers.first?.id }
        do { try commit(next) } catch { notice = error.localizedDescription }
    }
    func removeServer(_ id: String) {
        var next = state
        next.servers.removeAll { $0.id == id }
        if next.selectedID == id { next.selectedID = next.servers.first?.id }
        do { try commit(next) } catch { notice = error.localizedDescription }
    }
    func setRouting(_ value: RoutingPreferences) {
        var next = state
        next.routing = value
        do { try commit(next) } catch { notice = error.localizedDescription }
    }
    func probe(_ server: VPNServer) async {
        guard probing.isEmpty else { return } // one core instance: low memory on iPhone XS
        probing.insert(server.id)
        probeFailures.remove(server.id)
        defer { probing.remove(server.id) }
        do { latency[server.id] = try await CoreClient.latency(ConfigBuilder.make(server: server, routing: state.routing, probe: true)) }
        catch { latency.removeValue(forKey: server.id); probeFailures.insert(server.id) }
    }
    func probeAll() async {
        for server in state.servers {
            if Task.isCancelled { return }
            await probe(server)
        }
    }
}

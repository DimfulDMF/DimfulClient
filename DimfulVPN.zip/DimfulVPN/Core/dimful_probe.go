// SPDX-License-Identifier: GPL-3.0-or-later
// Copied into sing-box/experimental/libbox by Scripts/build-core.sh.
package libbox

import (
    "context"
    "fmt"
    "net/url"
    "strconv"
    "time"

    box "github.com/sagernet/sing-box"
    "github.com/sagernet/sing-box/common/urltest"
)

// DimfulProbe measures a real HTTP exchange through the proxy protocol, including
// VLESS/Trojan authentication and the Hysteria QUIC handshake. No TCP-only guess.
// configContent must be a ConfigBuilder probe config (no inbounds).
func DimfulProbe(configContent string, target string, timeoutMillis int32) (*StringBox, error) {
    u, err := url.Parse(target)
    if err != nil || u.Scheme != "https" || u.Hostname() == "" {
        return nil, fmt.Errorf("probe requires an HTTPS URL")
    }
    if timeoutMillis < 500 || timeoutMillis > 15000 {
        return nil, fmt.Errorf("invalid timeout")
    }
    ctx, cancel := context.WithTimeout(BaseContext(nil), time.Duration(timeoutMillis)*time.Millisecond)
    defer cancel()
    options, err := parseConfig(ctx, configContent)
    if err != nil { return nil, err }
    if len(options.Inbounds) != 0 { return nil, fmt.Errorf("probe cannot open inbounds") }
    instance, err := box.New(box.Options{Context: ctx, Options: options})
    if err != nil { return nil, err }
    defer instance.Close()
    if err = instance.Start(); err != nil { return nil, err }
    outbound, found := instance.Outbound().Outbound("proxy")
    if !found { return nil, fmt.Errorf("missing proxy outbound") }
    delay, err := urltest.URLTest(ctx, target, outbound)
    if err != nil { return nil, err }
    return wrapString(strconv.Itoa(int(delay))), nil
}

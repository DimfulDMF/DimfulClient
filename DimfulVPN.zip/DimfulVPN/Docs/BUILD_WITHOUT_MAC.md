# Как собрать Dimful VPN в IPA без своего Mac

В комплекте исходники, а не готовый IPA. iOS-сборка пока не подтверждена:
здесь не было Xcode и доступа к запуску GitHub Actions. Ниже — настройка
облачной сборки; результат появится после её успешного завершения.

Свой Mac не нужен. Xcode запускается на macOS-сервере GitHub.

## Вариант 1: только iPhone

1. Скачай **DimfulVPN.zip** из ответа и сохрани в «Файлы». Не переименовывай архив.
2. В Safari открой GitHub, войди и создай новый репозиторий, например `DimfulVPN`.
   Можно выбрать Private. Проверь доступные минуты Actions в своём аккаунте;
   macOS-runner расходует квоту. Включи добавление README при создании.
3. Через **Add file → Upload files** загрузи сам `DimfulVPN.zip` в корень
   репозитория и нажми **Commit changes**. Распаковывать его для загрузки не нужно.
4. Через **Add file → Create new file** создай файл с точным путём
   **`.github/workflows/build-ipa.yml`**. Скопируй в него весь код workflow
   из раздела в конце этой инструкции. Сохрани **Commit changes** в `main`.
   Если кнопки не видны, включи «Запросить настольный веб-сайт» в Safari.
5. Открой **Actions → Build iPhone IPA → Run workflow**.
6. Для первой сборки выбери `signing: unsigned`. `bundle_id` пока можно оставить
   `app.dimful.vpn`. Нажми **Run workflow**. Сервер сам распакует архив, соберёт
   VPN-ядро и запустит проверки и Xcode.
7. После зелёной сборки открой её страницу → **Artifacts → DimfulVPN-unsigned**.
   Скачай ZIP-артефакт и распакуй в «Файлах»: внутри будет
   **`DimfulVPN-unsigned.ipa`** и SHA-256.

Первая сборка может занять десятки минут. Красный workflow означает ошибку,
а не готовый результат. Открой упавший шаг и найди первое сообщение `error:`.
Без успешного Xcode build IPA не публикуется.

## Вариант 2: Windows / Linux

Распакуй `DimfulVPN.zip`. Создай пустой репозиторий GitHub. Установи Git, затем
открой терминал **внутри папки DimfulVPN**, где находится `project.yml`:

```bash
git init
git add .
git commit -m "Add Dimful VPN iOS client"
git branch -M main
git remote add origin https://github.com/YOUR_LOGIN/DimfulVPN.git
git push -u origin main
```

Замени `YOUR_LOGIN` своим логином. Если Git просит имя и email автора коммита,
настрой их; если просит вход, используй обычный вход GitHub для Git.
Не вводи пароль Apple ID в Git. Папка `.github` должна попасть в репозиторий.
Далее Actions → Build iPhone IPA → Run workflow, как выше.

## Как получить устанавливаемый IPA

**Unsigned IPA нельзя просто открыть и установить на обычный iPhone.**
Для системного VPN нужны настоящие разрешения Apple у приложения и расширения.
Установка произвольной бесплатной подписью может не поддерживать эти разрешения.
Один случайный `.p12` без нужных профилей задачу не решает.

Для встроенной подписанной сборки нужны:

| Что | Требование |
|---|---|
| Apple certificate `.p12` | С приватным ключом; действующий, совпадает с обоими профилями |
| Profile основного приложения | Точный App ID, Network Extensions, App Groups, UDID iPhone |
| Profile расширения | Точный App ID с `.PacketTunnel`, те же разрешения/группа и UDID |
| Тип профилей | Оба Ad Hoc либо оба development; для прямой установки не App Store |
| App Group | Одинаковая у обоих App ID: `group.` + основной Bundle ID |

Нормальный самостоятельный путь — аккаунт Apple Developer Program с доступом
к Certificates, Identifiers & Profiles. Если сертификат предоставляет другой
уполномоченный владелец аккаунта, он также должен создать эти два совместимых
профиля и зарегистрировать твой iPhone.

### Настройка на сайте Apple

1. Выбери уникальный основной Bundle ID, например `app.dimful.myvpn123`.
2. В Apple Developer → Certificates, Identifiers & Profiles зарегистрируй:
   - App ID `app.dimful.myvpn123`;
   - App ID `app.dimful.myvpn123.PacketTunnel`;
   - App Group `group.app.dimful.myvpn123`.
3. Включи **Network Extensions** и **App Groups** у обоих App ID.
   Назначь обоим созданную группу. Нужный entitlement —
   `com.apple.developer.networking.networkextension = [packet-tunnel-provider]`.
4. Зарегистрируй UDID своего iPhone в Devices.
5. Создай два профиля **Ad Hoc** с одним Apple Distribution сертификатом
   и этим iPhone. Либо два development-профиля с одним Apple Development
   сертификатом. Скачай оба `.mobileprovision`.
6. Нужен `.p12`, содержащий сертификат и соответствующий приватный ключ.
   Один скачанный у Apple `.cer` приватного ключа не содержит.

### Если сертификата ещё нет: CSR без Mac

В Windows можно использовать OpenSSL из доверенной установки, например WSL Ubuntu.
Команды выполняются локально в отдельной папке. Приватный ключ остаётся у тебя.

```bash
openssl genrsa -out ios-signing.key 2048
openssl req -new -key ios-signing.key -out ios-signing.csr
```

Второй вызов спросит данные для CSR. На сайте Apple создай Apple Distribution
(для Ad Hoc) или Apple Development сертификат, загрузи `ios-signing.csr`
и скачай `ios_certificate.cer`. Затем:

```bash
openssl x509 -inform DER -in ios_certificate.cer -out ios_certificate.pem
openssl pkcs12 -export -inkey ios-signing.key -in ios_certificate.pem -out certificate.p12
```

Задай пароль экспорта. Если macOS `security import` не принимает PKCS#12,
для OpenSSL 3 можно повторить экспорт с `-legacy`, используя те же исходные файлы.
Не коммить приватный ключ, `.p12` и профили в репозиторий.
С телефона этот шаг можно пропустить, если `.p12` и оба готовых профиля уже есть.

### Secrets GitHub

В репозитории открой **Settings → Secrets and variables → Actions → New repository secret**.

| Имя секрета | Значение |
|---|---|
| `CERT_P12_BASE64` | Base64 содержимого `.p12` |
| `CERT_P12_PASSWORD` | Пароль `.p12` |
| `APP_PROFILE_BASE64` | Base64 профиля основного приложения |
| `TUNNEL_PROFILE_BASE64` | Base64 профиля PacketTunnel |

PowerShell (запускай в папке с файлами):

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path .\certificate.p12))) | Set-Clipboard
```

Вставь буфер в `CERT_P12_BASE64`. Аналогично сделай для каждого профиля, заменив
имя файла. Либо Python без Mac:

```bash
python3 -c "import base64; from pathlib import Path; print(base64.b64encode(Path('certificate.p12').read_bytes()).decode())"
```

На iPhone готовые файлы можно преобразовать в Base64 локальным действием
приложения «Команды»: выбрать файл → кодировать Base64 → копировать в буфер.
Не отправляй приватный ключ в публичные онлайн-конвертеры.

Снова запусти workflow:

- `signing = signed`;
- `bundle_id = app.dimful.myvpn123` — твой **основной** Bundle ID;
- группа и суффикс расширения подставятся автоматически.

После успешной сборки скачай **DimfulVPN-signed** → **DimfulVPN-signed.ipa**.
Скрипт не удаляет VPN-entitlements, чтобы «продавить» установку; при
несовместимых профилях он завершится понятной ошибкой.

## Установка на iPhone

Подписанный IPA устанавливается только на устройства, включённые в ОБА профиля.
Можно использовать инструмент установки IPA на Windows, который сохраняет
готовую подпись, или собственную HTTPS OTA-раздачу Ad Hoc. Простое скачивание
IPA в Safari установку не запускает.

Если у тебя Linux и установлен `ideviceinstaller`, подключи разблокированный
iPhone по USB, подтверди «Доверять этому компьютеру» и выполни:

```bash
idevicepair pair
ideviceinstaller install DimfulVPN-signed.ipa
```

У старых версий вместо подкоманды `install` используется `-i`:
`ideviceinstaller -i DimfulVPN-signed.ipa`. Инструмент устанавливает уже
подписанный пакет, не выдаёт ему новые разрешения Apple.
Документация: https://github.com/libimobiledevice/ideviceinstaller.

Если используешь переподписывающий инструмент, у него должны быть совместимые
профили для обоих targets. Автоматическая замена Bundle ID, удаление расширения,
App Group или VPN-entitlements сломает клиент. Для development-подписи iOS может
потребовать Developer Mode; следуй системному сообщению телефона.

При первом подключении в Dimful VPN разреши iOS добавить конфигурацию VPN.
Затем добавь свою подписку, проверь сервер до подключения и нажми кнопку питания.

## Частые ошибки

| Ошибка | Что проверить |
|---|---|
| `Actions` не показывает workflow | Файл точно `.github/workflows/build-ipa.yml`, в основной ветке |
| `unzip: cannot find DimfulVPN.zip` | Для загрузки с телефона архив должен лежать в корне и называться ровно так |
| `Unexpected sing-box revision` | Не заменён ли тег ядра; нужен зафиксированный commit |
| `Missing ... secret` | Все 4 Secrets заданы в этом репозитории |
| `Profile lacks Network Extension` | Network Extensions включена у обоих App ID; профили перевыпущены |
| `Profile lacks App Group` | Одинаковая группа назначена обоим App ID и включена в новые профили |
| `exact bundle ID` | Input `bundle_id` совпадает с основным App ID |
| `P12 ... does not match BOTH profiles` | Оба профиля созданы с тем сертификатом, чей ключ находится в `.p12` |
| `App Group недоступна` в приложении | Подписывающий инструмент не изменил группу/Bundle ID и не удалил entitlement |
| Сервер «Нет ответа» | Пароль/SNI/Reality-параметры, доступность UDP у Hysteria, доступность тестового сайта |
| Банк идёт через VPN | Добавь отдельные API/CDN-домены банка, переподключись |
| Ошибка Swift/Libbox при первой сборке | Сохрани первое сообщение компилятора; не считай проект проверенным до зелёного workflow |

## Код workflow

Вставь следующий блок целиком в `.github/workflows/build-ipa.yml`.

```yaml
name: Build iPhone IPA
on:
  workflow_dispatch:
    inputs:
      signing:
        description: 'unsigned = IPA для последующей подписи; signed = использовать Secrets'
        type: choice
        options: [unsigned, signed]
        default: unsigned
      bundle_id:
        description: 'Bundle ID основного приложения (как в профиле Apple)'
        type: string
        default: app.dimful.vpn
        required: true
permissions:
  contents: read
concurrency:
  group: dimful-ipa-${{ github.ref }}
  cancel-in-progress: true
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 90
    env:
      BUNDLE_ID: ${{ inputs.bundle_id }}
    steps:
      - uses: actions/checkout@v4
      - name: Unpack source archive (phone upload)
        run: |
          if [[ ! -f project.yml ]]; then
            unzip -q DimfulVPN.zip -d source-archive
            cp -R source-archive/DimfulVPN/. .
          fi
      - uses: actions/setup-go@v5
        with:
          go-version: '1.25.7'
          cache: false
      - name: Toolchain
        run: |
          xcodebuild -version
          swift --version
          go version
          brew install xcodegen
      - name: Parser, routing and signing tests
        run: |
          swift test
          python3 -m unittest discover -s Tests -p 'test_*.py' -v
      - name: Generate fixtures from actual Swift configuration builder
        run: |
          mkdir -p build/fixtures
          swiftc Shared/Models.swift Shared/SubscriptionParser.swift Shared/ConfigBuilder.swift Tests/FixtureGenerator.swift -o build/generate-fixtures
          build/generate-fixtures build/fixtures
      - name: Build the real VPN core
        run: bash Scripts/build-core.sh
      - name: Validate generated configurations with the pinned core
        run: |
          cd build/sing-box
          go build -tags with_quic,with_utls,with_gvisor,with_clash_api -o ../sing-box-check ./cmd/sing-box
          cd ../..
          for config in build/fixtures/*.json; do build/sing-box-check check -c "$config"; done
      - name: Build unsigned IPA
        if: inputs.signing == 'unsigned'
        run: bash Scripts/build-ipa.sh unsigned
      - name: Build signed IPA
        if: inputs.signing == 'signed'
        env:
          CERT_P12_BASE64: ${{ secrets.CERT_P12_BASE64 }}
          CERT_P12_PASSWORD: ${{ secrets.CERT_P12_PASSWORD }}
          APP_PROFILE_BASE64: ${{ secrets.APP_PROFILE_BASE64 }}
          TUNNEL_PROFILE_BASE64: ${{ secrets.TUNNEL_PROFILE_BASE64 }}
        run: bash Scripts/build-ipa.sh signed
      - name: Downloadable IPA
        uses: actions/upload-artifact@v4
        with:
          name: DimfulVPN-${{ inputs.signing }}
          path: |
            build/DimfulVPN-*.ipa
            build/DimfulVPN-*.sha256
          if-no-files-found: error
          retention-days: 7
```

#!/usr/bin/env python3
import plistlib
import sys
import zipfile

with zipfile.ZipFile(sys.argv[1]) as archive:
    names = set(archive.namelist())
    prefix = 'Payload/DimfulVPN.app/'
    app = plistlib.loads(archive.read(prefix + 'Info.plist'))
    ext_prefix = prefix + 'PlugIns/PacketTunnel.appex/'
    ext = plistlib.loads(archive.read(ext_prefix + 'Info.plist'))
    assert ext['CFBundleIdentifier'] == app['CFBundleIdentifier'] + '.PacketTunnel'
    assert app['AppGroupIdentifier'] == ext['AppGroupIdentifier']
    assert ext['NSExtension']['NSExtensionPointIdentifier'] == 'com.apple.networkextension.packet-tunnel'
    for directory, info in [(prefix, app), (ext_prefix, ext)]:
        binary = archive.read(directory + info['CFBundleExecutable'])
        assert binary[:4] in [b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe', b'\xfe\xed\xfa\xcf'], 'Missing Mach-O executable'
        if sys.argv[2] == 'signed':
            assert directory + 'embedded.mobileprovision' in names
            assert directory + '_CodeSignature/CodeResources' in names
    print('IPA structure verified: real executables, app, packet tunnel, matching groups.')

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build_mode="${1:-unsigned}"
if [[ "$build_mode" != unsigned && "$build_mode" != signed ]]; then
  echo 'Usage: bash Scripts/build-ipa.sh unsigned|signed' >&2
  exit 1
fi
python3 Scripts/configure.py
xcodegen generate
xcodebuild -project DimfulVPN.xcodeproj -scheme DimfulVPN -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= build
mkdir -p build/package
rm -rf build/package/Payload
mkdir -p build/package/Payload
ditto build/DerivedData/Build/Products/Release-iphoneos/DimfulVPN.app build/package/Payload/DimfulVPN.app
test -d build/package/Payload/DimfulVPN.app/PlugIns/PacketTunnel.appex
if [[ "$build_mode" == signed ]]; then
  python3 Scripts/sign.py build/package/Payload/DimfulVPN.app
fi
output="DimfulVPN-${build_mode}.ipa"
rm -f "build/$output"
(cd build/package && /usr/bin/zip -qry "../$output" Payload)
python3 Scripts/verify-ipa.py "build/$output" "$build_mode"
shasum -a 256 "build/$output" > "build/$output.sha256"

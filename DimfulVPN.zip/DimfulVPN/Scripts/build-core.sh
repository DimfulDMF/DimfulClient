#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
CORE_TAG=v1.12.24
CORE_SHA=bc2b0820a096a802180d87ff67cba4322182073a
mkdir -p build Frameworks
if [[ ! -d build/sing-box/.git ]]; then
  git clone --depth 1 --branch "$CORE_TAG" https://github.com/SagerNet/sing-box.git build/sing-box
fi
actual_sha=$(git -C build/sing-box rev-parse HEAD)
if [[ "$actual_sha" != "$CORE_SHA" ]]; then
  echo "Unexpected sing-box revision. Remove build/sing-box and retry." >&2
  exit 1
fi
cp Core/dimful_probe.go build/sing-box/experimental/libbox/dimful_probe.go
cd build/sing-box
go install github.com/sagernet/gomobile/cmd/gomobile@v0.1.8
go install github.com/sagernet/gomobile/cmd/gobind@v0.1.8
export PATH="$(go env GOPATH)/bin:$PATH"
gomobile init
go run ./cmd/internal/build_libbox -target apple -platform ios
cd ../..
rm -rf Frameworks/Libbox.xcframework
mv build/sing-box/Libbox.xcframework Frameworks/Libbox.xcframework
# Keep the generated ABI alongside logs when investigating compile failures.
test -f Frameworks/Libbox.xcframework/Info.plist

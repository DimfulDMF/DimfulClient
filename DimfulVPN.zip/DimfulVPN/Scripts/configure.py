#!/usr/bin/env python3
import os
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
bundle = os.environ.get('BUNDLE_ID', 'app.dimful.vpn')
if not re.fullmatch(r'[A-Za-z][A-Za-z0-9-]*(?:\.[A-Za-z0-9-]+){2,}', bundle):
    raise SystemExit('BUNDLE_ID must be a reverse-DNS identifier, e.g. app.dimful.myvpn')
if bundle.endswith('.PacketTunnel'):
    raise SystemExit('Use the main app ID, without .PacketTunnel')
project = root / 'project.yml'
text = project.read_text()
text = re.sub(r'(?m)^(    APP_BUNDLE_ID: ).*$', lambda m: m[1] + bundle, text)
text = re.sub(r'(?m)^(    APP_GROUP: ).*$', lambda m: m[1] + 'group.' + bundle, text)
project.write_text(text)
print('Bundle IDs configured:', bundle, bundle + '.PacketTunnel')

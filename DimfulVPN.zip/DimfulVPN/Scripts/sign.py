#!/usr/bin/env python3
"""Sign an app and its packet-tunnel extension on an ephemeral macOS runner.
Uses existing authorized profiles; never strips or invents VPN entitlements.
"""
import base64
import datetime as dt
import hashlib
import os
import plistlib
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

NETWORK = 'com.apple.developer.networking.networkextension'
GROUPS = 'com.apple.security.application-groups'

def validate_profile(profile, bundle_id, app_group):
    expiry = profile.get('ExpirationDate')
    if not expiry or expiry.replace(tzinfo=dt.timezone.utc) <= dt.datetime.now(dt.timezone.utc):
        raise ValueError('Provisioning profile expired or has no expiry')
    ent = profile['Entitlements']
    prefixes = profile.get('ApplicationIdentifierPrefix', [])
    if len(prefixes) != 1 or ent.get('application-identifier') != prefixes[0] + '.' + bundle_id:
        raise ValueError('Profile must match the exact bundle ID: ' + bundle_id)
    if 'packet-tunnel-provider' not in ent.get(NETWORK, []):
        raise ValueError('Profile lacks Network Extension packet-tunnel-provider: ' + bundle_id)
    if app_group not in ent.get(GROUPS, []):
        raise ValueError('Profile lacks App Group ' + app_group)
    teams = profile.get('TeamIdentifier', [])
    if len(teams) != 1 or ent.get('com.apple.developer.team-identifier') != teams[0]:
        raise ValueError('Invalid team in provisioning profile')
    # Ad Hoc / development installation. App Store profiles need TestFlight and
    # are deliberately rejected to avoid producing an un-installable artifact.
    if not profile.get('ProvisionedDevices'):
        raise ValueError('Use an Ad Hoc or development profile containing your iPhone UDID')
    allowed = {
        'application-identifier': ent['application-identifier'],
        'com.apple.developer.team-identifier': teams[0],
        NETWORK: ['packet-tunnel-provider'], GROUPS: [app_group],
        'get-task-allow': bool(ent.get('get-task-allow', False)),
    }
    if 'keychain-access-groups' in ent:
        allowed['keychain-access-groups'] = [g.replace('*', bundle_id) for g in ent['keychain-access-groups']]
    return teams[0], allowed

def run(args, capture=False):
    result = subprocess.run(args, check=True, stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
                            stderr=subprocess.PIPE)
    return result.stdout if capture else b''

def decode_secret(name, target):
    value = os.environ.get(name, '')
    if not value:
        raise ValueError('Missing GitHub Actions secret: ' + name)
    target.write_bytes(base64.b64decode(''.join(value.split()), validate=True))
    target.chmod(0o600)

def sign(app):
    bundle = plistlib.loads((app / 'Info.plist').read_bytes())['CFBundleIdentifier']
    app_group = 'group.' + bundle
    extension = app / 'PlugIns/PacketTunnel.appex'
    if not extension.is_dir():
        raise ValueError('PacketTunnel.appex is missing')
    with tempfile.TemporaryDirectory(prefix='dimful-sign-', dir=os.environ.get('RUNNER_TEMP')) as temp:
        temp = Path(temp)
        cert, app_prov, ext_prov = [temp / name for name in ('certificate.p12', 'app.mobileprovision', 'tunnel.mobileprovision')]
        decode_secret('CERT_P12_BASE64', cert)
        decode_secret('APP_PROFILE_BASE64', app_prov)
        decode_secret('TUNNEL_PROFILE_BASE64', ext_prov)
        profiles = [plistlib.loads(run(['security', 'cms', '-D', '-i', str(p)], True)) for p in (app_prov, ext_prov)]
        main_team, main_ent = validate_profile(profiles[0], bundle, app_group)
        ext_team, ext_ent = validate_profile(profiles[1], bundle + '.PacketTunnel', app_group)
        if main_team != ext_team:
            raise ValueError('Both profiles must belong to the same Apple team')
        if main_ent['get-task-allow'] != ext_ent['get-task-allow']:
            raise ValueError('Do not mix development and distribution profiles')
        if not set(profiles[0]['ProvisionedDevices']) & set(profiles[1]['ProvisionedDevices']):
            raise ValueError('Profiles have no common registered iPhone')
        common = set(hashlib.sha1(c).hexdigest().upper() for c in profiles[0]['DeveloperCertificates'])
        common &= set(hashlib.sha1(c).hexdigest().upper() for c in profiles[1]['DeveloperCertificates'])
        keychain = temp / 'signing.keychain-db'
        keychain_password = secrets.token_urlsafe(32)
        try:
            run(['security', 'create-keychain', '-p', keychain_password, str(keychain)])
            run(['security', 'set-keychain-settings', '-lut', '21600', str(keychain)])
            run(['security', 'unlock-keychain', '-p', keychain_password, str(keychain)])
            run(['security', 'import', str(cert), '-k', str(keychain), '-P', os.environ.get('CERT_P12_PASSWORD', ''),
                 '-T', '/usr/bin/codesign', '-T', '/usr/bin/security'])
            run(['security', 'set-key-partition-list', '-S', 'apple-tool:,apple:,codesign:', '-s', '-k', keychain_password, str(keychain)])
            identities = run(['security', 'find-identity', '-v', '-p', 'codesigning', str(keychain)], True).decode()
            matches = [sha for sha in re.findall(r'\b[0-9A-F]{40}\b', identities) if sha in common]
            if not matches:
                raise ValueError('P12 certificate/private key does not match BOTH profiles or certificate trust is invalid')
            identity = matches[0]
            ent_paths = []
            for name, ent in [('app', main_ent), ('tunnel', ext_ent)]:
                path = temp / (name + '.entitlements')
                path.write_bytes(plistlib.dumps(ent))
                ent_paths.append(path)
            shutil.copyfile(app_prov, app / 'embedded.mobileprovision')
            shutil.copyfile(ext_prov, extension / 'embedded.mobileprovision')
            def codesign(path, entitlements=None):
                cmd = ['codesign', '--force', '--sign', identity, '--keychain', str(keychain), '--timestamp=none']
                if entitlements:
                    cmd += ['--entitlements', str(entitlements), '--generate-entitlement-der']
                run(cmd + [str(path)])
            for path in sorted(app.rglob('*.dylib')):
                codesign(path)
            for path in sorted(app.rglob('*.framework'), key=lambda p: -len(p.parts)):
                codesign(path)
            codesign(extension, ent_paths[1])
            codesign(app, ent_paths[0])
            run(['codesign', '--verify', '--deep', '--strict', str(app)])
            print('Signed and verified app + PacketTunnel with matching VPN/App Group profiles.')
        finally:
            if keychain.exists():
                subprocess.run(['security', 'delete-keychain', str(keychain)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if __name__ == '__main__':
    try:
        sign(Path(sys.argv[1]).resolve())
    except subprocess.CalledProcessError as error:
        # CalledProcessError.__str__ contains command arguments, possibly secrets.
        print('Signing tool failed. Check P12 password, certificate trust and provisioning profiles.', file=sys.stderr)
        sys.exit(1)
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)

#!/usr/bin/env python3
"""Generate the code-native Dimful mark. Requires Pillow only to regenerate."""
from pathlib import Path
import json
from PIL import Image, ImageDraw, ImageFilter

size = 1024
image = Image.new('RGB', (size, size))
pixels = image.load()
for y in range(size):
    for x in range(size):
        glow = max(0, 1 - ((x - 420)**2 + (y - 400)**2)**0.5 / 800)
        pixels[x, y] = (int(11 + 48*glow), int(12 + 24*glow), int(27 + 80*glow))
halo = Image.new('RGBA', image.size)
d = ImageDraw.Draw(halo)
d.ellipse((220, 220, 804, 804), outline=(168, 120, 255, 140), width=38)
image = Image.alpha_composite(image.convert('RGBA'), halo.filter(ImageFilter.GaussianBlur(45)))
d = ImageDraw.Draw(image)
d.ellipse((155, 155, 869, 869), outline=(110, 79, 181, 255), width=3)
d.arc((270, 245, 778, 765), -90, 90, fill=(202, 180, 255), width=84)
d.line((350, 290, 350, 735), fill=(248, 246, 255), width=84)
d.line((350, 287, 513, 287), fill=(225, 207, 255), width=84)
d.line((350, 722, 513, 722), fill=(225, 207, 255), width=84)
d.ellipse((663, 705, 769, 811), fill=(107, 240, 197))
root = Path(__file__).resolve().parents[1] / 'Resources/Assets.xcassets'
icon = root / 'AppIcon.appiconset'
icon.mkdir(parents=True, exist_ok=True)
image.convert('RGB').save(icon / 'AppIcon.png')
(root / 'Contents.json').write_text(json.dumps({'info': {'author': 'xcode', 'version': 1}}, indent=2))
(icon / 'Contents.json').write_text(json.dumps({'images': [{'filename': 'AppIcon.png', 'idiom': 'universal', 'platform': 'ios', 'size': '1024x1024'}], 'info': {'author': 'xcode', 'version': 1}}, indent=2))

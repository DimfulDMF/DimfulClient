// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation
import CryptoKit

struct VPNFailure: LocalizedError {
    let message: String
    init(_ message: String) { self.message = message }
    var errorDescription: String? { message }
}

struct VPNServer: Codable, Identifiable, Equatable {
    let id: String
    var name: String
    let kind: String
    let host: String
    let port: Int
    let outboundJSON: String
    var subscriptionID: UUID?

    init(name: String, outbound: [String: Any], subscriptionID: UUID? = nil) throws {
        guard let kind = outbound["type"] as? String,
              ["vless", "trojan", "hysteria", "hysteria2"].contains(kind),
              let host = outbound["server"] as? String, !host.isEmpty,
              let port = outbound["server_port"] as? Int, (1...65535).contains(port) else {
            throw VPNFailure("Нужен отдельный VLESS, Trojan, Hysteria или Hysteria 2 сервер с адресом и портом.")
        }
        guard outbound["detour"] == nil else {
            throw VPNFailure("Цепочки серверов (detour) пока не поддерживаются.")
        }
        var clean = outbound
        clean["tag"] = "proxy"
        clean["domain_resolver"] = "dns-direct"
        clean.removeValue(forKey: "domain_strategy")
        let bytes = try JSONSerialization.data(withJSONObject: clean, options: [.sortedKeys, .withoutEscapingSlashes])
        self.outboundJSON = String(decoding: bytes, as: UTF8.self)
        self.id = SHA256.hash(data: Data((subscriptionID?.uuidString ?? "manual").utf8) + bytes)
            .map { String(format: "%02x", $0) }.joined()
        self.name = name.isEmpty ? host : String(name.prefix(160))
        self.kind = kind
        self.host = host
        self.port = port
        self.subscriptionID = subscriptionID
    }

    var label: String { kind == "hysteria2" ? "HY2" : kind.uppercased() }
    var skipsTLSVerification: Bool {
        guard let data = outboundJSON.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let tls = object["tls"] as? [String: Any] else { return false }
        return tls["insecure"] as? Bool == true
    }
}

struct Subscription: Codable, Identifiable {
    var id = UUID()
    var name: String
    var url: String
    var updatedAt: Date?
    var importedCount = 0
}

struct RoutingPreferences: Codable, Equatable {
    var directRussianZones = true
    var directPrivateNetworks = true
    var extraDomains: [String] = []
    var directDNS = "77.88.8.8"

    static let serviceDomains = [
        "max.ru", "vk.com", "vk.ru", "vk.me", "vk.cc", "vkuser.net", "vkuser.com",
        "vk-cdn.net", "userapi.com", "vk-cdn.me", "vkvideo.ru", "mycdn.me",
        "avito.ru", "avito.st", "avito.com", "gosuslugi.ru", "esia.gosuslugi.ru",
        "sberbank.ru", "sberbank.com", "sber.ru", "sberbank-online.ru", "sberdevices.ru",
        "tbank.ru", "tinkoff.ru", "tinkoffbank.ru", "tinkoff.com", "tcsbank.ru",
        "alfabank.ru", "alfa-bank.ru", "alfabank.com", "vtb.ru", "vtb24.ru",
        "gazprombank.ru", "rshb.ru", "psbank.ru", "raiffeisen.ru", "raiffeisen.com",
        "rosbank.ru", "sovcombank.ru", "mkb.ru", "otpbank.ru", "ubrr.ru",
        "domrfbank.ru", "bspb.ru", "akbars.ru", "novikom.ru", "unicreditbank.ru",
        "yoomoney.ru", "yoo.money", "nspk.ru", "sbp.nspk.ru", "mironline.ru"
    ]

    var domains: [String] {
        Array(Set(Self.serviceDomains + extraDomains +
                  (directRussianZones ? ["ru", "su", "xn--p1ai"] : []))).sorted()
    }

    static func normalizeDomain(_ input: String) throws -> String {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if text.contains("://") { text = URLComponents(string: text)?.host ?? "" }
        while text.hasPrefix(".") { text.removeFirst() }
        while text.hasSuffix(".") { text.removeLast() }
        guard !text.isEmpty, !text.contains("*"), !text.contains("/"), !text.contains(":") else {
            throw VPNFailure("Введите домен без пути, порта и звёздочек: example.com")
        }
        // URL.host performs IDNA conversion on supported Apple OS versions.
        guard let host = URL(string: "https://" + text)?.host,
              host.range(of: #"^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$"#, options: .regularExpression) != nil,
              !host.contains(".."), host.count <= 253,
              host.split(separator: ".").allSatisfy({ $0.count <= 63 && !$0.hasPrefix("-") && !$0.hasSuffix("-") }) else {
            throw VPNFailure("Некорректный домен.")
        }
        return host
    }

    func isDirect(domain: String) -> Bool {
        guard let host = try? Self.normalizeDomain(domain) else { return false }
        return domains.contains { host == $0 || host.hasSuffix("." + $0) }
    }
}

struct SavedState: Codable {
    var servers: [VPNServer] = []
    var subscriptions: [Subscription] = []
    var selectedID: String?
    var routing = RoutingPreferences()
}

struct ImportResult {
    var servers: [VPNServer]
    var warnings: [String]
}

// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation

enum SharedPaths {
    static var group: String {
        Bundle.main.object(forInfoDictionaryKey: "AppGroupIdentifier") as? String ?? "group.app.dimful.vpn"
    }
    static func directory() throws -> URL {
        guard let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw VPNFailure("App Group недоступна. Проверьте одинаковую группу и entitlements приложения и PacketTunnel при подписи.")
        }
        let folder = url.appendingPathComponent("Library/Application Support/DimfulVPN", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true,
                                              attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        var resourceURL = folder
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try resourceURL.setResourceValues(values)
        return folder
    }
    static func configURL() throws -> URL { try directory().appendingPathComponent("active.json") }
    static func writeConfig(_ value: String) throws {
        try Data(value.utf8).write(to: configURL(), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}

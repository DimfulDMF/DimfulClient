// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation

enum SubscriptionParser {
    static let maxBytes = 4 * 1024 * 1024
    static let maxServers = 1000

    static func parse(_ text: String, subscriptionID: UUID? = nil) throws -> ImportResult {
        guard text.utf8.count <= maxBytes else { throw VPNFailure("Подписка больше 4 МБ.") }
        var content = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if !content.contains("://"), !content.hasPrefix("{"), !content.hasPrefix("["),
           let decoded = decodeBase64(content), decoded.contains("://") || decoded.hasPrefix("{") {
            content = decoded
        }
        var nodes: [VPNServer] = []
        var warnings: [String] = []
        if content.hasPrefix("{") || content.hasPrefix("[") {
            let root = try JSONSerialization.jsonObject(with: Data(content.utf8))
            let outbounds: [[String: Any]]
            if let object = root as? [String: Any], let list = object["outbounds"] as? [[String: Any]] {
                outbounds = list
            } else if let list = root as? [[String: Any]] {
                outbounds = list
            } else if let object = root as? [String: Any] {
                outbounds = [object]
            } else { throw VPNFailure("Не найден список sing-box outbounds.") }
            guard outbounds.count <= maxServers else { throw VPNFailure("Не более 1000 записей в подписке.") }
            for (index, outbound) in outbounds.enumerated() {
                if ["selector", "urltest", "direct", "block", "dns"].contains(outbound["type"] as? String ?? "") { continue }
                do {
                    nodes.append(try VPNServer(name: outbound["tag"] as? String ?? "", outbound: outbound, subscriptionID: subscriptionID))
                } catch { warnings.append("Запись \(index + 1): \(error.localizedDescription)") }
            }
        } else {
            let lines = content.components(separatedBy: .newlines)
            guard lines.count <= maxServers * 3 else { throw VPNFailure("Слишком много строк в подписке.") }
            for (index, line) in lines.enumerated() {
                let uri = line.trimmingCharacters(in: .whitespacesAndNewlines)
                if uri.isEmpty || uri.hasPrefix("#") { continue }
                do { nodes.append(try parseURI(uri, subscriptionID: subscriptionID)) }
                catch { warnings.append("Строка \(index + 1): \(error.localizedDescription)") }
            }
        }
        var seen = Set<String>()
        nodes = nodes.filter { seen.insert($0.id).inserted }
        guard !nodes.isEmpty else {
            throw VPNFailure("Нет поддерживаемых серверов. Нужны ссылки VLESS/Trojan/Hysteria, Base64 или JSON sing-box. Clash YAML не поддерживается. " + (warnings.first ?? ""))
        }
        guard nodes.count <= maxServers else { throw VPNFailure("Не более 1000 серверов.") }
        return ImportResult(servers: nodes, warnings: warnings)
    }

    static func decodeBase64(_ value: String) -> String? {
        var value = value.filter { !$0.isWhitespace }.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        value += String(repeating: "=", count: (4 - value.count % 4) % 4)
        guard let data = Data(base64Encoded: value) else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func parseURI(_ uri: String, subscriptionID: UUID? = nil) throws -> VPNServer {
        guard let u = URLComponents(string: uri), let scheme = u.scheme?.lowercased(),
              let rawHost = u.host, !rawHost.isEmpty else { throw VPNFailure("Некорректная ссылка сервера.") }
        let host = rawHost.trimmingCharacters(in: CharacterSet(charactersIn: "[]"))
        let kind = scheme == "hy2" ? "hysteria2" : scheme
        guard ["vless", "trojan", "hysteria", "hysteria2"].contains(kind) else {
            throw VPNFailure("Протокол этой записи не поддерживается.")
        }
        let port = u.port ?? 443
        var q: [String: String] = [:]
        for item in u.queryItems ?? [] { q[item.name.lowercased()] = item.value ?? "" }
        if q["pinsha256"] != nil || q["pin-sha256"] != nil {
            throw VPNFailure("Закреплённый сертификат импортируйте через JSON sing-box; параметр URI pinSHA256 не поддерживается.")
        }
        let user = u.user ?? ""
        let credential = u.password.map { user + ":" + $0 } ?? user
        var out: [String: Any] = ["type": kind, "server": host, "server_port": port]
        if q["mport"] != nil || q["ports"] != nil {
            throw VPNFailure("Port hopping импортируется только через JSON sing-box.")
        }
        if kind == "vless" {
            guard UUID(uuidString: user) != nil else { throw VPNFailure("VLESS: некорректный UUID.") }
            guard q["encryption"] == nil || q["encryption"] == "none" else { throw VPNFailure("VLESS encryption не поддерживается этим ядром.") }
            out["uuid"] = user
            if let flow = q["flow"], !flow.isEmpty {
                guard flow == "xtls-rprx-vision" else { throw VPNFailure("Неподдерживаемый VLESS flow.") }
                out["flow"] = flow
            }
        } else if kind == "trojan" || kind == "hysteria2" {
            guard !credential.isEmpty else { throw VPNFailure("В ссылке нет пароля сервера.") }
            out["password"] = credential
        } else {
            guard q["protocol"] == nil || q["protocol"] == "udp" else { throw VPNFailure("Hysteria 1: поддерживается transport UDP.") }
            out["auth_str"] = q["auth"] ?? credential
            out["up_mbps"] = max(1, Int(q["upmbps"] ?? q["up"] ?? "20") ?? 20)
            out["down_mbps"] = max(1, Int(q["downmbps"] ?? q["down"] ?? "100") ?? 100)
            if let obfs = q["obfsparam"], !obfs.isEmpty { out["obfs"] = obfs }
            else if let obfs = q["obfs"], !obfs.isEmpty {
                guard obfs != "xplus" else { throw VPNFailure("Hysteria: отсутствует obfsParam.") }
                out["obfs"] = obfs
            }
        }
        if kind == "hysteria2", let obfs = q["obfs"], !obfs.isEmpty {
            guard obfs == "salamander", let pass = q["obfs-password"], !pass.isEmpty else {
                throw VPNFailure("Hysteria 2: нужны obfs=salamander и obfs-password.")
            }
            out["obfs"] = ["type": "salamander", "password": pass]
        }
        let security = q["security"] ?? (kind == "vless" ? "none" : "tls")
        guard ["none", "tls", "reality"].contains(security) else { throw VPNFailure("Неподдерживаемый тип TLS.") }
        if security != "none" || kind != "vless" {
            var tls: [String: Any] = ["enabled": true, "server_name": q["sni"] ?? q["peer"] ?? host]
            if let alpn = q["alpn"], !alpn.isEmpty { tls["alpn"] = alpn.split(separator: ",").map(String.init) }
            tls["insecure"] = [q["allowinsecure"], q["insecure"], q["skip-cert-verify"]].contains { $0 == "1" || $0 == "true" }
            if let fp = q["fp"], !fp.isEmpty, (kind == "vless" || kind == "trojan") {
                tls["utls"] = ["enabled": true, "fingerprint": fp]
            }
            if security == "reality" {
                guard kind == "vless", let key = q["pbk"], !key.isEmpty else { throw VPNFailure("Reality: нет public key или выбран не VLESS.") }
                tls["reality"] = ["enabled": true, "public_key": key, "short_id": q["sid"] ?? ""]
                tls["utls"] = ["enabled": true, "fingerprint": q["fp"] ?? "chrome"]
            }
            out["tls"] = tls
        }
        if kind == "vless" || kind == "trojan" {
            let transport = q["type"] ?? "tcp"
            switch transport {
            case "tcp":
                guard q["headertype"] == nil || q["headertype"] == "none" else { throw VPNFailure("TCP HTTP header не поддерживается.") }
            case "ws":
                var t: [String: Any] = ["type": "ws", "path": q["path"] ?? "/"]
                if let host = q["host"], !host.isEmpty { t["headers"] = ["Host": host] }
                if let early = q["ed"], let count = Int(early), count >= 0 {
                    t["max_early_data"] = count
                    t["early_data_header_name"] = q["eh"] ?? "Sec-WebSocket-Protocol"
                }
                out["transport"] = t
            case "grpc":
                out["transport"] = ["type": "grpc", "service_name": q["servicename"] ?? ""]
            default: throw VPNFailure("Транспорт \(transport) пока не поддерживается. Доступны TCP, WS, gRPC.")
            }
        }
        return try VPNServer(name: u.fragment ?? host, outbound: out, subscriptionID: subscriptionID)
    }
}

// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation

enum ConfigBuilder {
    static func make(server: VPNServer, routing: RoutingPreferences, probe: Bool = false) throws -> String {
        guard let outbound = try JSONSerialization.jsonObject(with: Data(server.outboundJSON.utf8)) as? [String: Any] else {
            throw VPNFailure("Повреждён профиль сервера.")
        }
        let directDNS: [String: Any] = ["type": "udp", "tag": "dns-direct", "server": routing.directDNS, "server_port": 53]
        let remoteDNS: [String: Any] = [
            "type": "https", "tag": "dns-vpn", "server": "1.1.1.1", "server_port": 443,
            "path": "/dns-query", "detour": "proxy",
            "tls": ["enabled": true, "server_name": "cloudflare-dns.com"]
        ]
        var rules: [[String: Any]] = [
            ["action": "sniff", "timeout": "500ms"],
            ["protocol": "dns", "action": "hijack-dns"]
        ]
        if routing.directPrivateNetworks { rules.append(["ip_is_private": true, "action": "route", "outbound": "direct"]) }
        rules.append(["domain_suffix": routing.domains, "action": "route", "outbound": "direct"])
        var dns: [String: Any] = [
            "servers": [directDNS, remoteDNS],
            "rules": [["domain_suffix": routing.domains, "action": "route", "server": "dns-direct"]],
            "final": "dns-vpn", "strategy": "prefer_ipv4", "reverse_mapping": true,
            "independent_cache": true, "cache_capacity": 1024
        ]
        var route: [String: Any] = ["rules": rules, "final": "proxy", "auto_detect_interface": true, "default_domain_resolver": "dns-direct"]
        let tun: [String: Any] = [
            "type": "tun", "tag": "tun-in", "address": ["172.19.0.1/30", "fdfe:dcba:9876::1/126"],
            "mtu": 1400, "auto_route": true, "strict_route": true, "stack": "mixed"
        ]
        if probe {
            // No TUN or routing interception; the test dials the proxy outbound explicitly.
            route = ["final": "proxy", "default_domain_resolver": "dns-direct"]
            dns = ["servers": [directDNS], "final": "dns-direct", "strategy": "prefer_ipv4"]
        }
        let config: [String: Any] = [
            "log": ["level": "error", "timestamp": true],
            "dns": dns, "inbounds": probe ? [] : [tun],
            "outbounds": [outbound, ["type": "direct", "tag": "direct"]], "route": route
        ]
        return String(decoding: try JSONSerialization.data(withJSONObject: config, options: [.sortedKeys]), as: UTF8.self)
    }
}

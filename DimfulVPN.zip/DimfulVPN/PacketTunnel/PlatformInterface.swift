// SPDX-License-Identifier: GPL-3.0-or-later
// Adapter based on the PlatformInterface contract in sing-box v1.12.24 and
// SagerNet/sing-box-for-apple, copyright 2022 nekohasekai (GPL-3.0-or-later).
import Foundation
import Network
import NetworkExtension
import Libbox
import Darwin

final class PlatformInterface: NSObject, LibboxPlatformInterfaceProtocol {
    private unowned let tunnel: PacketTunnelProvider
    private var monitor: NWPathMonitor?
    private let monitorQueue = DispatchQueue(label: "app.dimful.vpn.path")

    init(_ tunnel: PacketTunnelProvider) { self.tunnel = tunnel }

    func openTun(_ options: LibboxTunOptionsProtocol?, ret0_: UnsafeMutablePointer<Int32>?) throws {
        guard let options, let ret0_ else { throw VPNFailure("Не переданы параметры TUN.") }
        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "127.0.0.1")
        settings.mtu = NSNumber(value: options.getMTU())
        let dns = try options.getDNSServerAddress()
        let dnsSettings = NEDNSSettings(servers: [dns.value])
        dnsSettings.matchDomains = [""]
        dnsSettings.matchDomainsNoSearch = true
        settings.dnsSettings = dnsSettings

        var addresses4: [String] = [], masks: [String] = []
        let iterator4 = options.getInet4Address()
        while iterator4?.hasNext() == true {
            if let prefix = iterator4?.next() { addresses4.append(prefix.address()); masks.append(prefix.mask()) }
        }
        let v4 = NEIPv4Settings(addresses: addresses4, subnetMasks: masks)
        v4.includedRoutes = [NEIPv4Route.default()]
        settings.ipv4Settings = v4

        var addresses6: [String] = [], prefixes6: [NSNumber] = []
        let iterator6 = options.getInet6Address()
        while iterator6?.hasNext() == true {
            if let prefix = iterator6?.next() { addresses6.append(prefix.address()); prefixes6.append(NSNumber(value: prefix.prefix())) }
        }
        let v6 = NEIPv6Settings(addresses: addresses6, networkPrefixLengths: prefixes6)
        v6.includedRoutes = [NEIPv6Route.default()]
        settings.ipv6Settings = v6

        // Direct exceptions are evaluated inside sing-box, for IPv4 and IPv6.
        // Excluding Russian IP ranges at the OS layer would bypass domain policy.
        let result = SettingsResult()
        tunnel.setTunnelNetworkSettings(settings) { error in result.finish(error) }
        try result.wait()
        let descriptor = LibboxGetTunnelFileDescriptor()
        guard descriptor >= 0 else { throw VPNFailure("iOS не предоставила файловый дескриптор TUN.") }
        ret0_.pointee = descriptor
    }

    func usePlatformAutoDetectControl() -> Bool { false }
    func autoDetectControl(_ fd: Int32) throws {}
    func useProcFS() -> Bool { false }
    func underNetworkExtension() -> Bool { true }
    func includeAllNetworks() -> Bool { false }
    func localDNSTransport() -> LibboxLocalDNSTransportProtocol? { nil }
    func systemCertificates() -> LibboxStringIteratorProtocol? { nil }
    func readWIFIState() -> LibboxWIFIState? { nil }
    func clearDNSCache() {} // No mutable selectors or live reload in this app.
    func writeLog(_ message: String?) {} // Do not persist destination/credential logs.
    func send(_ notification: LibboxNotification?) throws {}

    func findConnectionOwner(_ ipProtocol: Int32, sourceAddress: String?, sourcePort: Int32,
                             destinationAddress: String?, destinationPort: Int32,
                             ret0_: UnsafeMutablePointer<Int32>?) throws {
        throw VPNFailure("iOS не предоставляет владельца соединения.")
    }
    func packageName(byUid uid: Int32, error: NSErrorPointer) -> String { "" }
    func uid(byPackageName packageName: String?, ret0_: UnsafeMutablePointer<Int32>?) throws {
        throw VPNFailure("Правила по процессам недоступны на iOS.")
    }

    func startDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws {
        guard let listener else { throw VPNFailure("Нет наблюдателя интерфейса.") }
        shutdown()
        let monitor = NWPathMonitor()
        self.monitor = monitor
        let ready = DispatchSemaphore(value: 0)
        monitor.pathUpdateHandler = { path in
            if path.status == .satisfied, let interface = path.availableInterfaces.first(where: { path.usesInterfaceType($0.type) }) {
                listener.updateDefaultInterface(interface.name, interfaceIndex: Int32(interface.index),
                                                isExpensive: path.isExpensive, isConstrained: path.isConstrained)
            } else {
                listener.updateDefaultInterface("", interfaceIndex: -1, isExpensive: false, isConstrained: false)
            }
            ready.signal()
        }
        monitor.start(queue: monitorQueue)
        if ready.wait(timeout: .now() + 8) == .timedOut { shutdown(); throw VPNFailure("Не удалось определить сеть Wi-Fi/сотовую.") }
    }
    func closeDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws { shutdown() }
    func shutdown() { monitor?.cancel(); monitor = nil }

    func getInterfaces() throws -> LibboxNetworkInterfaceIteratorProtocol {
        guard let path = monitor?.currentPath else { throw VPNFailure("Наблюдатель сети не запущен.") }
        let interfaces: [LibboxNetworkInterface] = path.availableInterfaces.map { item in
            let output = LibboxNetworkInterface()
            output.name = item.name
            output.index = Int32(item.index)
            output.mtu = 1500
            output.flags = Int32(IFF_UP | IFF_RUNNING)
            output.addresses = StringIterator([])
            output.metered = path.isExpensive
            switch item.type {
            case .wifi: output.type = LibboxInterfaceTypeWIFI
            case .cellular: output.type = LibboxInterfaceTypeCellular
            case .wiredEthernet: output.type = LibboxInterfaceTypeEthernet
            default: output.type = LibboxInterfaceTypeOther
            }
            return output
        }
        return InterfaceIterator(interfaces)
    }
}

private final class SettingsResult {
    private let lock = NSLock()
    private let semaphore = DispatchSemaphore(value: 0)
    private var error: Error?
    func finish(_ error: Error?) { lock.lock(); self.error = error; lock.unlock(); semaphore.signal() }
    func wait() throws {
        guard semaphore.wait(timeout: .now() + 15) == .success else { throw VPNFailure("Тайм-аут настройки VPN в iOS.") }
        lock.lock(); let value = error; lock.unlock()
        if let value { throw value }
    }
}

private final class InterfaceIterator: NSObject, LibboxNetworkInterfaceIteratorProtocol {
    private let values: [LibboxNetworkInterface]
    private var index = 0
    init(_ values: [LibboxNetworkInterface]) { self.values = values }
    func hasNext() -> Bool { index < values.count }
    func next() -> LibboxNetworkInterface? {
        guard hasNext() else { return nil }
        defer { index += 1 }
        return values[index]
    }
}

private final class StringIterator: NSObject, LibboxStringIteratorProtocol {
    private let values: [String]
    private var index = 0
    init(_ values: [String]) { self.values = values }
    func hasNext() -> Bool { index < values.count }
    func next() -> String { guard hasNext() else { return "" }; defer { index += 1 }; return values[index] }
    func len() -> Int32 { Int32(values.count) }
}

// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation
import NetworkExtension
import Libbox

final class PacketTunnelProvider: NEPacketTunnelProvider {
    private let worker = DispatchQueue(label: "app.dimful.vpn.tunnel")
    private var service: LibboxBoxService?
    private var platform: PlatformInterface?

    override func startTunnel(options: [String: NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        worker.async {
            do {
                let directory = try SharedPaths.directory()
                let options = LibboxSetupOptions()
                options.basePath = directory.path
                options.workingPath = directory.appendingPathComponent("core").path
                options.tempPath = directory.appendingPathComponent("temp").path
                var error: NSError?
                LibboxSetup(options, &error)
                if let error { throw error }
                LibboxSetMemoryLimit(true)
                let config = try String(contentsOf: SharedPaths.configURL(), encoding: .utf8)
                LibboxCheckConfig(config, &error)
                if let error { throw error }
                let platform = PlatformInterface(self)
                self.platform = platform
                guard let service = LibboxNewService(config, platform, &error) else {
                    throw error ?? (VPNFailure("Не удалось создать VPN-ядро.") as NSError)
                }
                self.service = service
                try service.start()
                completionHandler(nil)
            } catch {
                try? self.service?.close()
                self.service = nil
                self.platform?.shutdown()
                self.platform = nil
                completionHandler(error)
            }
        }
    }

    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        worker.async {
            try? self.service?.close()
            self.service = nil
            self.platform?.shutdown()
            self.platform = nil
            completionHandler()
        }
    }

    override func sleep(completionHandler: @escaping () -> Void) {
        worker.async { self.service?.pause(); completionHandler() }
    }
    override func wake() { worker.async { self.service?.wake() } }
}

// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "DimfulLogic",
    platforms: [.macOS(.v13)],
    products: [.library(name: "DimfulLogic", targets: ["DimfulLogic"])],
    targets: [
        .target(name: "DimfulLogic", path: "Shared", exclude: ["SharedPaths.swift"]),
        .testTarget(name: "DimfulLogicTests", dependencies: ["DimfulLogic"], path: "Tests", exclude: ["FixtureGenerator.swift", "test_signing.py", "__pycache__"])
    ]
)
